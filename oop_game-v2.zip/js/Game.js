/* Treehouse FSJS Techdegree
 * Project 4 - OOP Game App
 * Game.js */